
$(document).ready(function () {

   $('.header').tabs();
  
  });