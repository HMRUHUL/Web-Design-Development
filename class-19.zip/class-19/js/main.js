
$(document).ready(function () {
  $('.main').mixItUp();
  
});

