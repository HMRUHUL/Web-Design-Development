$(document).ready(function () {


    wow = new WOW({
        boxClass: 'wow',
        animateClass: 'animated',
        offset: 10,
        mobile: true,
        live: true

    });
    wow.init();

});