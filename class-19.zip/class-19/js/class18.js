// $(document).ready(function(){
//     $('.galbox a').prettyPhoto();
//     Animation_speed:'slow';
// });

// $(document).ready(function(){

//     var st = [ 'Maleeeeha', "Ruhul", "Tamim", 
//     " Jahidul","Anas", "Fazla", "Fahim",
//     "Maruf", "Wahia", "Nishat","Sajal",
//     "Nazmul Vai"];

//     $('.search  input').autocomplete({

//         source: st,
//     });

// });

$(document).ready(function(){
    $('#date').datepicker();

});

// $(document).ready(function(){
//     $('.amader-acc').accordion();

// });